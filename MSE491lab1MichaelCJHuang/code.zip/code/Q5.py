from Q1 import xvar, yvar
from Q2 import x_train, x_test, y_train, y_test, X, Y

import random
import math
import numpy as np
from sklearn import preprocessing
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.linear_model import LinearRegression

def viz_polymonial(Xpv_train, ypv_train, poly_pred, xlabel, ylabel):
    plt.scatter(Xpv_train, ypv_train, color='red')
    plt.plot(Xpv_train, poly_pred, color='blue')
    plt.title('Polymonial Regression with 1 Feature for visualization')
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.show()
    return

    import random
from sklearn import preprocessing
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures

def polyReg (deg, y):
    # Try with polynomial of degree 3
    degree = deg
    randFeats = ['AT','AP','AH','AFDP']
    ypv_train = y_train[y]
    Xpv_train = x_train[randFeats]
    Xpv_train = np.array(Xpv_train).reshape(-1, 4)
    ypv_train = np.array(ypv_train).reshape(-1, 1)

    # Standardizing features by removing the mean and scaling to unit variance
    scaler = preprocessing.StandardScaler()
    polyreg_scaled = make_pipeline(PolynomialFeatures(degree),scaler,LinearRegression())
    polyreg_scaled.fit(Xpv_train,ypv_train)

    # Save Model
    pickle.dump(polyreg_scaled, open('Model5'+y+str(deg)+'.pkl', 'wb'))

    xTest = np.array(x_test[randFeats]).reshape(-1,4)
    poly_pred = polyreg_scaled.predict(xTest)

    yTest = np.array(y_test[y]).reshape(-1,1)
    poly_reg_r2 = r2_score(yTest, poly_pred)
    mse = mean_squared_error(yTest, poly_pred)
    rmse = math.sqrt(mse)
    
    # print('rmse: ',rmse, 'r2: ', lin_reg_r2)
    return rmse, poly_reg_r2

results = []
for j in [2,5,11]:
    for y in yvar:
        print(j,y)
        rmse, r2 = polyReg(j, y)
        result = [j, y, rmse, r2]
        print(result)
        results.append(result)

# MemoryError: Unable to allocate 16.5 GiB for an array with shape (29386, 75582) and data type float64